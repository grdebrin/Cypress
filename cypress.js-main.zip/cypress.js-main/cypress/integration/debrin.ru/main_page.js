describe("Тестирование главной страницы", function () {
  it("Проверка, что на главной странице присутствует - Georgiy Debrin", function () {
    cy.visit("https://debrin.ru");
    cy.get(".header__title").should("have.text", "Georgiy Debrin");
  });
  it("Проверка, что на главной странице присутствует - QA Engineer", function () {
    cy.visit("https://debrin.ru");
    cy.get(".header__subtitle").should("have.text", "QA Engineer");
  });
  it("Проверка, что на главной странице присутствует раздел - Social", function () {
    cy.visit("https://debrin.ru");
    cy.get(":nth-child(1) > .links__header").should("have.text", "Social");
  });
  it("Проверка, что Telegram указан верный", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(1) > .links__container > :nth-child(1) > .links__link"
    ).should("have.text", "@gr_debrin");
  });
  it("Проверка, что e-mail указан верный", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(1) > .links__container > :nth-child(2) > .links__link"
    ).should("have.text", "qa.debrin@gmail.com");
  });
  it("Проверка, что CV указан верный", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(1) > .links__container > :nth-child(3) > .links__link"
    ).should("have.text", "resume");
  });
  it("Проверка, что LinkedIn указан верный", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(1) > .links__container > :nth-child(4) > .links__link"
    ).should("have.text", "georgiy-debrin");
  });
  it("Проверка, что GitHub указан верный", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(1) > .links__container > :nth-child(5) > .links__link"
    ).should("have.text", "github.com/grdebrin");
  });
  it("Проверка, что на главной странице присутствует раздел - Hobby", function () {
    cy.visit("https://debrin.ru");
    cy.get(":nth-child(2) > .links__header").should("have.text", "Hobby");
  });
  it("Проверка, что указана ссылка на Testing", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(2) > .links__container > :nth-child(1) > .links__link"
    ).should("have.text", "Certificates");
  });
  it("Проверка, что указана ссылка на Coding", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(2) > .links__container > :nth-child(2) > .links__link"
    ).should("have.text", "Code");
  });
  it("Проверка, что указана ссылка на Reading", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(2) > .links__container > :nth-child(3) > .links__link"
    ).should("have.text", "Books");
  });
  it("Проверка, что указана ссылка на Investing", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(2) > .links__container > :nth-child(4) > .links__link"
    ).should("have.text", "Interactive Brokers");
  });
  it("Проверка, что указана ссылка на Music", function () {
    cy.visit("https://debrin.ru");
    cy.get(
      ":nth-child(2) > .links__container > :nth-child(5) > .links__link"
    ).should("have.text", "Spotify");
  });
});
