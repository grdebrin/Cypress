describe("Тестирование страницы Сертификаты", function () {
  it("Проверка, что на странице присутствует раздел - Сертификатов Вадима Ксендзова", function () {
    cy.visit("https://debrin.ru/certificates.html");
    cy.get("#ksendzov").should(
      "have.text",
      "\n        Курс тестирования ПО Вадима Ксендзова\n      "
    );
  });
  it("Проверка, что на странице присутствует раздел - Сертификатов Udemy", function () {
    cy.visit("https://debrin.ru/certificates.html");
    cy.get("#udemy").should("have.text", "Курсы Udemy по тестированию");
  });
  it("Проверка, что на странице присутствует раздел - Сертификатов SQL", function () {
    cy.visit("https://debrin.ru/certificates.html");
    cy.get(":nth-child(3) > .certificates-title").should("have.text", "SQL");
  });
  it("Проверка, что на странице присутствует раздел - Сертификатов HTML & CSS", function () {
    cy.visit("https://debrin.ru/certificates.html");
    cy.get(":nth-child(4) > .certificates-title").should(
      "have.text",
      "HTML & CSS"
    );
  });
  it("Проверка, что на странице присутствует раздел - Сертификатов SNG", function () {
    cy.visit("https://debrin.ru/certificates.html");
    cy.get("#sng").should("have.text", "SNG");
  });
});
