describe("Тестирование страницы Резюме", function () {
  it("Проверка, что на странице присутствует - Дебрин Георгий", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(".title__h1").should("have.text", "Дебрин Георгий");
  });
  it("Проверка, что на странице присутствует - QA Engineer", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(".title__h2").should("have.text", "qa engineer");
  });
  it("Проверка, что на странице присутствует раздел - контакты", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(".contacts > .title__h3").should("have.text", "контакты");
  });
  it("Проверка, что на странице присутствует раздел - обо мне", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(".about > .title__h3").should("have.text", "обо мне");
  });
  it("Проверка, что на странице присутствует раздел - навыки", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(".skills > .title__h3").should("have.text", "навыки");
  });
  it("Проверка, что на странице присутствует раздел - языки", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(".language > .title__h3").should("have.text", "языки");
  });
  it("Проверка, что на странице присутствует раздел - опыт работы", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(".work > .title__h3").should("have.text", "опыт работы");
  });
  it("Проверка, что на странице присутствует актуальный опыт", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(":nth-child(2) > .work__position").should(
      "have.text",
      "\n                август 2023 - настоящее время \n                QA Engineer -\n                SimbirSoft\n              "
    );
  });
  it("Проверка, что на странице присутствует раздел - образование", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(".education > .title__h3").should("have.text", "образование");
  });
  it("Проверка, что на странице присутствует ссылка на скачивание резюме", function () {
    cy.visit("https://debrin.ru/resume.html");
    cy.get(".link__download > a").should(
      "have.text",
      "Ссылка на скачивание PDF-версии"
    );
  });
});
